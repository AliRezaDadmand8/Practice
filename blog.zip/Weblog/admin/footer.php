</div>
                </div>
                <div class=" container  d-flex flex-column flex-md-row align-items-center justify-content-between">
                    <div class="nav nav-dark order-1 order-md-2">
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/plugins/global/plugins.bundle.js?v=7.0.6"></script>
    <script src="assets/plugins/custom/prismjs/prismjs.bundle.js?v=7.0.6"></script>
    <script src="assets/js/scripts.bundle.js?v=7.0.6"></script>
    <script src="assets/plugins/custom/fullcalendar/fullcalendar.bundle.js?v=7.0.6"></script>
    <script src="assets/js/pages/widgets.js?v=7.0.6"></script>
</body>

</html>