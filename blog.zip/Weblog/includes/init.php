<?php ob_start();
session_start();
require_once 'connect.php';
require_once 'functions.php';
