<?php
include_once 'includes/connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) and isset($_POST['email']) and isset($_POST['password'])) {
        if (!empty($_POST['username']) and !empty($_POST['email']) and !empty($_POST['password'])) {
            $result = insertUserData($_POST['username'], $_POST['email'], $_POST['password']);
        }
    }
}
function insertUserData($username, $email, $age)
{
    global $db;
    $sql = "INSERT INTO 'admins' ('admin_username' ,'admin_email' ,'admin_password') VALUES ($username,$email,$password)";


    $stmt = $db->prepare($sql);
    $stmt->execute([':username' => $username, ':email' => $email, ':age' => $password]);
    return $stmt->rowCount();
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create user</title>
    <style>
        .container {
            margin: 20px auto;
            width: 24%;
            text-align: left;
            border: 1px solid rgb(16, 9, 59);
            padding: 14px 26px;
            border-radius: 6px;
        }
        .form-control {
            padding: 8px;
        }
        input {
            border-radius: 5px;
            border: 1px solid rgb(16, 9, 59);
            padding: 8px 9px;
        }
        input#username {
            margin-left: 55px;
        }
        input#password {
            margin-left: 60px;
        }
       
        input#email {
            margin-left: 82px;
        }
        input[type="submit"] {
            background-color: dodgerblue;
            color: white;
            cursor: pointer;
        }
        label {
            margin-right: 22px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form class="sabtenam" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
            <div class="form-control">
                <label for='username'>Username</label>
                <input type="text" id="username" name="username" placeholder="Enter your username">
            </div>
            <div class="form-control">
                <label for='email'>Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email">
            </div>
            <div class="form-control">
            <label for='password'>Password</label>
            <input type="text" id="password" name="frmpassword" placeholder="Enter your password">
       
            <div class="form-control">
                <center><input type="submit" value="Submit" name="submit_btn">
            </div>
        </form>
    </div>
</body>
</html>